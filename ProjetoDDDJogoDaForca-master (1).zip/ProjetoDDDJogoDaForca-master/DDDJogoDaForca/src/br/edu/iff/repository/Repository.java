package br.edu.iff.repository;

public interface Repository {
	long getProximoId();
}
