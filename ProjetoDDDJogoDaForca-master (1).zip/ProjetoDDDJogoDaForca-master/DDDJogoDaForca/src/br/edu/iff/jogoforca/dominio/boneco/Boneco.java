package br.edu.iff.jogoforca.dominio.boneco;

public interface Boneco extends BonecoFactory{
	void exibir (Object contexto, int partes);
}
