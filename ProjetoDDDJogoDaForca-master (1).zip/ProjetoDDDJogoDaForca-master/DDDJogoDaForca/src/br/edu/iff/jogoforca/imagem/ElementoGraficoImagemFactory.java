package br.edu.iff.jogoforca.imagem;

import br.edu.iff.bancodepalavras.dominio.letra.Letra;
import br.edu.iff.bancodepalavras.dominio.letra.imagem.LetraImagemFactory;
import br.edu.iff.jogoforca.ElementoGraficoFactory;
import br.edu.iff.jogoforca.dominio.boneco.Boneco;
import br.edu.iff.jogoforca.dominio.boneco.imagem.BonecoImagemFactory;

public class ElementoGraficoImagemFactory implements ElementoGraficoFactory{
	private static ElementoGraficoImagemFactory soleInstance = null;
	private BonecoImagemFactory bonecoImagemFactory;
	private ElementoGraficoImagemFactory() {
		this.bonecoImagemFactory = BonecoImagemFactory.getSoleInstance();
	}
	
	public static ElementoGraficoImagemFactory getSoleInstance() {
		//thread safety
		if (soleInstance == null) {
			synchronized(ElementoGraficoImagemFactory.class){
				if (soleInstance == null) {//verifica novamente para tratar a concorr�ncia
					soleInstance = new ElementoGraficoImagemFactory();
				}	
			}
		}
		return soleInstance;
	}
	
	public Boneco getBoneco() {
		return bonecoImagemFactory.getBoneco(); 
	}
	
	@Override
	public Letra getLetra(char codigo) {
		return LetraImagemFactory.getSoleInstance().getLetra(codigo);
	}

	@Override
	public Letra getLetraEncoberta() {
		return LetraImagemFactory.getSoleInstance().getLetraEncoberta();
	}
}
