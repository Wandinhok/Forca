package br.edu.iff.jogoforca.emmemoria;

import br.edu.iff.bancodepalavras.dominio.palavra.PalavraRepository;
import br.edu.iff.bancodepalavras.dominio.palavra.emmemoria.MemoriaPalavraRepository;
import br.edu.iff.bancodepalavras.dominio.tema.TemaRepository;
import br.edu.iff.bancodepalavras.dominio.tema.emmemoria.MemoriaTemaRepository;
import br.edu.iff.jogoforca.RepositoryFactory;
import br.edu.iff.jogoforca.dominio.jogador.JogadorRepository;
import br.edu.iff.jogoforca.dominio.jogador.emmemoria.MemoriaJogadorRepository;
import br.edu.iff.jogoforca.dominio.rodada.RodadaRepository;
import br.edu.iff.jogoforca.dominio.rodada.emmemoria.MemoriaRodadaRepository;

public class MemoriaRepositoryFactory implements RepositoryFactory{

	private static MemoriaRepositoryFactory soleInstance = null;
	
	private MemoriaRepositoryFactory() {
		
	}
	
	public static synchronized MemoriaRepositoryFactory getSoleInstance() {
		if (soleInstance == null) 
			soleInstance = new MemoriaRepositoryFactory();
		return soleInstance;
	} 
	
	public PalavraRepository getPalavraRepository() {
		return (PalavraRepository) MemoriaPalavraRepository.getSoleInstance();
	}
	public TemaRepository getTemaRepository() {
		return (TemaRepository) MemoriaTemaRepository.getSoleInstance();
	}
	public JogadorRepository getJogadorRepository() {
		return (JogadorRepository) MemoriaJogadorRepository.getSoleInstance();
	}
	public RodadaRepository getRodadaRepository() {
		return (RodadaRepository) MemoriaRodadaRepository.getSoleInstance();
	}
}
