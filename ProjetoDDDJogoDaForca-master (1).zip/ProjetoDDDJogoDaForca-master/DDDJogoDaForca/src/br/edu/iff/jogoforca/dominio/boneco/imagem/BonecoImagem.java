package br.edu.iff.jogoforca.dominio.boneco.imagem;

import br.edu.iff.jogoforca.dominio.boneco.Boneco;

public class BonecoImagem implements Boneco{
	private static BonecoImagem soleInstance = null;
	
	private BonecoImagem() {
		
	}
	
	public static BonecoImagem getSoleInstance() {
		//thread safety
		if (soleInstance == null) {
			synchronized(BonecoImagem.class){
				if (soleInstance == null) {//verifica novamente para tratar a concorr�ncia
					soleInstance = new BonecoImagem();
				}	
			}
		}
		return soleInstance;
	}
	@Override
	public Boneco getBoneco() {
		return BonecoImagemFactory.getSoleInstance().getBoneco();
	}

	@Override
	public void exibir(Object contexto, int partes) {
		// TODO Auto-generated method stub
		
	}
	
}