package br.edu.iff.jogoforca;

import br.edu.iff.bancodepalavras.dominio.palavra.Palavra;
import br.edu.iff.bancodepalavras.dominio.palavra.PalavraFactory;
import br.edu.iff.bancodepalavras.dominio.palavra.PalavraFactoryImpl;
import br.edu.iff.bancodepalavras.dominio.tema.TemaFactory;
import br.edu.iff.bancodepalavras.dominio.tema.TemaFactoryImpl;
import br.edu.iff.jogoforca.dominio.jogador.JogadorFactory;
import br.edu.iff.jogoforca.dominio.jogador.JogadorFactoryImpl;
import br.edu.iff.jogoforca.dominio.rodada.Rodada;
import br.edu.iff.jogoforca.dominio.rodada.RodadaFactory;
import br.edu.iff.jogoforca.dominio.rodada.RodadaFactoryImpl;
import br.edu.iff.jogoforca.dominio.rodada.sorteio.RodadaSorteioFactory;
import br.edu.iff.jogoforca.emmemoria.MemoriaRepositoryFactory;
import br.edu.iff.jogoforca.texto.ElementoGraficoTextoFactory;

public class Aplicacao {
    private final static String[] TIPOS_REPOSITORY_FACTORY = { "memoria", "relacional" };
    private final static String[] TIPOS_ELEMENTO_GRAFICO_FACTORY = { "texto", "imagem" };
    private final static String[] TIPOS_RODADA_FACTORY = { "sorteio" };
    private static Aplicacao soleInstance = null;
    private String tipoRepositoryFactory = TIPOS_REPOSITORY_FACTORY[0];
    private String tipoElementoGraficoFactory = TIPOS_ELEMENTO_GRAFICO_FACTORY[0];
    private String tipoRodadaFactory = TIPOS_RODADA_FACTORY[0];
    private MemoriaRepositoryFactory memoriaRepositoryFactory;
    private ElementoGraficoFactory elementoGraficoFactory;
    private RodadaFactory rodadaFactory;
    
    private Aplicacao() {
		super();
	}
    
    public void configurar() {
        if (tipoRepositoryFactory.equals(TIPOS_REPOSITORY_FACTORY[0]) && tipoElementoGraficoFactory.equals(TIPOS_ELEMENTO_GRAFICO_FACTORY[0]) && tipoRodadaFactory.equals(TIPOS_RODADA_FACTORY[0])) {
        	
        	memoriaRepositoryFactory = MemoriaRepositoryFactory.getSoleInstance();
        	elementoGraficoFactory = ElementoGraficoTextoFactory.getSoleInstance();
            
            RodadaSorteioFactory.createSoleInstance(memoriaRepositoryFactory.getRodadaRepository(), memoriaRepositoryFactory.getTemaRepository(), memoriaRepositoryFactory.getPalavraRepository());
            rodadaFactory = RodadaSorteioFactory.getSoleInstance();
        }

        TemaFactoryImpl.createSoleInstance(memoriaRepositoryFactory.getTemaRepository());
        PalavraFactoryImpl.createSoleInstance(memoriaRepositoryFactory.getPalavraRepository());
        JogadorFactoryImpl.createSoleInstance(memoriaRepositoryFactory.getJogadorRepository());
        
        Palavra.setLetraFactory(elementoGraficoFactory);
        Rodada.setBonecoFactory(elementoGraficoFactory);
    }
    
    public static Aplicacao getSoleInstance() {
        if (soleInstance == null) {
            soleInstance = new Aplicacao();
        }	

        return soleInstance;
    }

	public static String[] getTiposRepositoryFactory() {
		return TIPOS_REPOSITORY_FACTORY;
	}

	public static String[] getTiposElementoGraficoFactory() {
		return TIPOS_ELEMENTO_GRAFICO_FACTORY;
	}

	public static String[] getTiposRodadaFactory() {
		return TIPOS_RODADA_FACTORY;
	}
	
	public void setTipoRepositoryFactory(String tipoRepositoryFactory) {
		this.tipoRepositoryFactory = tipoRepositoryFactory;
	}

	public void setTipoElementoGraficoFactory(String tipoElementoGraficoFactory) {
		this.tipoElementoGraficoFactory = tipoElementoGraficoFactory;
	}
	
	public void setTipoRodadaFactory(String tipoRodadaFactory) {
		this.tipoRodadaFactory = tipoRodadaFactory;
	}

    public TemaFactory getTemaFactory() {
        return TemaFactoryImpl.getSoleInstance();
    }

    public PalavraFactory getPalavraFactory() {
        return PalavraFactoryImpl.getSoleInstance();
    }

    public JogadorFactory getJogadorFactory() {
        return JogadorFactoryImpl.getSoleInstance();
    }
	
    public RodadaFactory getRodadaFactory() {
        return  rodadaFactory;
    }
    
    public ElementoGraficoFactory getElementoGraficoFactory() {
        return elementoGraficoFactory;
    }
    
    public RepositoryFactory getRepositoryFactory() {
    	return memoriaRepositoryFactory;
    }
}
