package br.edu.iff.jogoforca.dominio.rodada;

import java.util.List;

import br.edu.iff.jogoforca.dominio.jogador.Jogador;
import br.edu.iff.repository.Repository;
import br.edu.iff.repository.RepositoryException;

public interface RodadaRepository extends Repository{
	Rodada getPorId(long id);
	List<Rodada> getPorJogador(Jogador jogador);
	void inserir(Rodada rodada) throws RepositoryException;
	void atualizar(Rodada rodada) throws RepositoryException;
	void remover(Rodada rodada) throws RepositoryException;
}
