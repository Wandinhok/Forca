package br.edu.iff.jogoforca.dominio.jogador;

import br.edu.iff.jogoforca.EntityFactory;

public class JogadorFactoryImpl extends EntityFactory implements JogadorFactory{
	private static JogadorFactoryImpl soleInstance= null;
	
	protected JogadorFactoryImpl(JogadorRepository repository) {
		super(repository);
	}
	
	public static void createSoleInstance(JogadorRepository repository) {
		soleInstance = new JogadorFactoryImpl(repository);
	}
	
	public static JogadorFactoryImpl getSoleInstance() {
	    if (soleInstance == null) {
	        throw new RuntimeException("Erro! Jogador Factory n�o foi inicializada.");
	    }
		return soleInstance;
	}
	
	private JogadorRepository getJogadorRepository() {
		return (JogadorRepository) repository;
	}
	
	public Jogador getJogador(String nome) {
		if(getJogadorRepository().getPorNome(nome) == null) {
			return Jogador.criar(repository.getProximoId(), nome);
		}
		return getJogadorRepository().getPorNome(nome);
	}
	
	
}
