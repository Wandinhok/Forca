
package br.edu.iff.jogoforca.dominio.rodada;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.stream.Collectors;

import br.edu.iff.bancodepalavras.dominio.letra.Letra;
import br.edu.iff.bancodepalavras.dominio.palavra.Palavra;
import br.edu.iff.bancodepalavras.dominio.tema.Tema;
import br.edu.iff.dominio.ObjetoDominioImpl;
import br.edu.iff.jogoforca.ElementoGraficoFactory;
import br.edu.iff.jogoforca.dominio.boneco.Boneco;
import br.edu.iff.jogoforca.dominio.boneco.BonecoFactory;
import br.edu.iff.jogoforca.dominio.jogador.Jogador;

public class Rodada extends ObjetoDominioImpl {

	private static int maxpalavras = 3;
	private static int maxErros = 10;
	private Item[] itens = new Item[maxErros];
	private Jogador jogador;
	private static int pontosQuandoDescobreTodasAsPalavras = 100;
	private static int pontosPorLetraEncoberta = 15;
	private Boneco boneco;
	private static BonecoFactory bonecoFactory = null; // talvez n�o precise ter j� que chama o met�do est�tico
	private Letra[] letras = new Letra[maxErros];
	private Palavra[] palavras;
	
	private Set<Letra> certas;
	private Set<Letra> erradas;

//Somente pode pode chamar o construtor da classe, se o boneco factory tiver sido setado. No
// construtor, cria os itens e chama getBonecoFactory() para criar o boneco. O id do item
// corresponde ao �ndice do vetor de palavras passado
	public Rodada(long id, Palavra[] palavras, Jogador jogador) {
		super(id);
		this.itens = new Item[maxpalavras];
		this.jogador = jogador;
		this.palavras = palavras;
		boneco = getBonecoFactory().getBoneco();
		this.certas = new HashSet<>();
		this.erradas = new HashSet<>();
		this.itens = new Item[palavras.length];
	    for (int i = 0; i < palavras.length; i++) {
	        this.itens[i] = Item.criar(i, palavras[i]);
	     }
	}

	private Rodada(long id, Item[] itens, Letra[] erradas, Jogador jogador) {
		super(id);
		this.itens = new Item[maxpalavras];
		this.letras = erradas;
		this.jogador = jogador;
		boneco = getBonecoFactory().getBoneco();
		this.certas = new HashSet<>();
		this.erradas = new HashSet<>();

	    for (int i = 0; i < itens.length; i++) {
	        Item item = itens[i];
	       
	        this.itens[i] = item;
	   
	        for (Letra correta: item.getLetrasDescobertas()) {
	          this.certas.add(correta);
	        }
	      }
	   
	      for (Letra errada: erradas) {
	        this.erradas.add(errada);
	      }
	}

	public static int getMaxpalavras() {
		return maxpalavras;
	}

	public static void setMaxpalavras(int maxpalavras) {
		Rodada.maxpalavras = maxpalavras;
	}

	public static int getMaxErros() {
		return maxErros;
	}

	public static void setMaxErros(int maxErros) {
		Rodada.maxErros = maxErros;
	}

	public static int getPontosQuandoDescobreTodasAsPalavras() {
		return pontosQuandoDescobreTodasAsPalavras;
	}

	public static void setPontosQuandoDescobreTodasAsPalavras(int pontosQuandoDescobreTodasAsPalavras) {
		Rodada.pontosQuandoDescobreTodasAsPalavras = pontosQuandoDescobreTodasAsPalavras;
	}

	public static int getPontosPorLetraEncoberta() {
		return pontosPorLetraEncoberta;
	}

	public static void setPontosPorLetraEncoberta(int pontosPorLetraEncoberta) {
		Rodada.pontosPorLetraEncoberta = pontosPorLetraEncoberta;
	}

	public static BonecoFactory getBonecoFactory() {
		return bonecoFactory;
	}

	public static void setBonecoFactory(BonecoFactory bFactory) {
		bonecoFactory = bFactory;
	}

	public static Rodada criar(long id, Palavra[] palavras, Jogador jogador) {
	    try {
			if (getBonecoFactory() == null) {
			    throw new RuntimeException("Boneco Factory n�o inicializada!"); 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new Rodada(id, palavras, jogador);
	}

	public static Rodada reconstituir(long id, Item[] itens, Letra[] erradas, Jogador jogador) {
	    try {
			if (getBonecoFactory() == null) {
			    throw new RuntimeException("Boneco Factory n�o inicializada!"); 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new Rodada(id, itens, erradas, jogador);
	}

	public Jogador getJogador() {
		return jogador;
	}

	public Palavra[] getPalavras() {
		return palavras;
	}

	public Tema getTema() {
		for(Palavra palavra : palavras) {
			return palavra.getTema();
		}
		return null;

	}

	public int getNumPalavras() {
		return palavras.length;

	}

	public void tentar(char codigo) {
		if (encerrou()) {
			return;
		}
        Map<Item, Boolean> itensCorretos = new HashMap<>();
        
        ElementoGraficoFactory letraFactory = (ElementoGraficoFactory) Palavra.getLetraFactory();
   
        for (Item item: itens) {
           
          if (item.tentar(codigo) == true) {
              certas.add(letraFactory.getLetra(codigo));
             
              itensCorretos.put(item, true);
          } 
          else {
              itensCorretos.put(item, false);
          }
         
        }
   
        if (!itensCorretos.containsValue(true)) {
          erradas.add(letraFactory.getLetra(codigo));
        }
   
        if (encerrou() == true) {
            this.jogador.setPontuacao(this.calcularPontos());
        }		
		jogador.setPontuacao(calcularPontos()); // se n�o encerrou deve atualizar os pontos do jogador
	}

	public void arriscar(String[] palavras) {
		
	    if (encerrou()) {
	        return;
	    }
	    
	    // se n�o encerrou deve atualizar os pontos do jogador
        int aux = 0;
        
        if (palavras.length < itens.length) {
            aux = palavras.length;
        } else {
            aux = itens.length;
        }
   
        for (int i = 0; i < aux; i++) {
            itens[i].arriscar(palavras[i]);
        }
   
        if (encerrou() == true) {
            this.jogador.setPontuacao(this.calcularPontos());
        }
	}

	public void exibirItens(Object contexto) {
	    for (Item i: itens) {
	        i.exibir(contexto);
	       
	        System.out.println();
	    }

	}

	public void exibirBoneco(Object contexto) {
		boneco.exibir(contexto, getQtdeErros());
	}

	public void exibirPalavras(Object contexto) {
	    for (Palavra p: getPalavras()) {
	        p.exibir(contexto);
	       
	        System.out.println();
	    }
	}

	public void exibirLetrasErradas(Object contexto) {
	    for (Letra a: erradas) {
	        a.exibir(contexto);
	       
	        System.out.println();
	    }
	}

	public Set<Letra> getTentativas() {
		Set<Letra> tentar = new HashSet<>();

		tentar.addAll(certas);

		tentar.addAll(erradas);

		return tentar;

	}

	public Set<Letra> getCertas() {
		return Collections.unmodifiableSet(certas);

	}

	public  Set<Letra> getErradas() {
		return Collections.unmodifiableSet(erradas);
	}

	public int calcularPontos() {
		if (!descobriu()) {
			return 0;
		}
		int pontos = 0;	
		pontos = pontosQuandoDescobreTodasAsPalavras + (pontosPorLetraEncoberta * getPontosPorLetraEncoberta());
		return pontos;
	}

	public boolean encerrou() {
		if (arriscou() || descobriu() || getQtdeErros() == maxErros)
			return true;
		return false;
	}

	public boolean descobriu() {
	    for (Item i: itens) {
	        if (!i.descobriu()) {
		          return false;
	        }
	    }
	       
	    return true;
	}

	public boolean arriscou() {
	    for (Item i: itens) {
	        if (i.arriscou() == true) {
	        	return true;
	        }
	    }
	     
	    return false;
	}

	public int getQtdeTentativasRestantes() {
		return getMaxErros() - erradas.size();
	}

	public int getQtdeErros() {
		return erradas.size();

	}

	public int getQtdeAcertos() {
		return certas.size();

	}

	public int getQtdeTentativas() {
		return getQtdeErros() + getQtdeAcertos();
	}

}