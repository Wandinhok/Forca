package br.edu.iff.jogoforca.dominio.boneco.texto;

import br.edu.iff.jogoforca.dominio.boneco.Boneco;


public class BonecoTexto implements Boneco{

	private static BonecoTexto soleInstance = null;
	
	private BonecoTexto() {
		
	}
	
	public static BonecoTexto getSoleInstance() {
		//thread safety
		if (soleInstance == null) {
			synchronized(BonecoTexto.class){
				if (soleInstance == null) {//verifica novamente para tratar a concorręncia
					soleInstance = new BonecoTexto();
				}	
			}
		}
		return soleInstance;
	}
	
	@Override
	public Boneco getBoneco() {
		return BonecoTextoFactory.getSoleInstance().getBoneco();
	}

	@Override
	public void exibir(Object contexto, int partes) {
		switch(partes) {
			case 0:
				System.out.println("--------------------------");
				System.out.println("|-------------------------");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				break;
			case 1:
				System.out.println("--------------------------");
				System.out.println("|----------------------|--");
				System.out.println("|                    __|__");
				System.out.println("|                    |   |");
				System.out.println("|                    |   |");
				System.out.println("|                    |___|");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				break;
			case 2:
				System.out.println("--------------------------");
				System.out.println("|----------------------|--");
				System.out.println("|                    __|__");
				System.out.println("|                    |o  |");
				System.out.println("|                    |   |");
				System.out.println("|                    |___|");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				break;	
			case 3:
				System.out.println("--------------------------");
				System.out.println("|----------------------|--");
				System.out.println("|                    __|__");
				System.out.println("|                    |o o|");
				System.out.println("|                    |   |");
				System.out.println("|                    |___|");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				break;
			case 4:
				System.out.println("--------------------------");
				System.out.println("|----------------------|--");
				System.out.println("|                    __|__");
				System.out.println("|                    |o o|");
				System.out.println("|                    | ' |");
				System.out.println("|                    |___|");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				break;	
			case 5:
				System.out.println("--------------------------");
				System.out.println("|----------------------|--");
				System.out.println("|                    __|__");
				System.out.println("|                    |o o|");
				System.out.println("|                    | ' |");
				System.out.println("|                    |_=_|");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				break;					
			case 6:
				System.out.println("--------------------------");
				System.out.println("|----------------------|--");
				System.out.println("|                    __|__");
				System.out.println("|                    |o o|");
				System.out.println("|                    | ' |");
				System.out.println("|                    |_=_|");
				System.out.println("|                     | | ");
				System.out.println("|                     | | ");
				System.out.println("|                     | | ");
				System.out.println("|                     | | ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				break;	
			case 7:
				System.out.println("-----------------------------");
				System.out.println("|----------------------|-----");
				System.out.println("|                    __|__   ");
				System.out.println("|                    |o o|   ");
				System.out.println("|                    | ' |   ");
				System.out.println("|                    |_=_|   ");
				System.out.println("|                    /| |    ");
				System.out.println("|                   / | |    ");
				System.out.println("|                  /  | |    ");
				System.out.println("|                     | |    ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				break;	
			case 8:
				System.out.println("-----------------------------");
				System.out.println("|----------------------|-----");
				System.out.println("|                    __|__   ");
				System.out.println("|                    |o o|   ");
				System.out.println("|                    | ' |   ");
				System.out.println("|                    |_=_|   ");
				System.out.println("|                    /| |\\   ");
				System.out.println("|                   / | | \\  ");
				System.out.println("|                  /  | |  \\ ");
				System.out.println("|                     | |      ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				System.out.println("|                              ");
				break;	
			case 9:
				System.out.println("-----------------------------");
				System.out.println("|----------------------|-----");
				System.out.println("|                    __|__   ");
				System.out.println("|                    |o o|   ");
				System.out.println("|                    | ' |   ");
				System.out.println("|                    |_=_|   ");
				System.out.println("|                    /| |\\   ");
				System.out.println("|                   / | | \\  ");
				System.out.println("|                  /  | |  \\ ");
				System.out.println("|                     | |      ");
				System.out.println("|                     /       ");
				System.out.println("|                    /        ");
				System.out.println("|                   /         ");
				System.out.println("|                            ");
				break;
			case 10:
				System.out.println("-----------------------------");
				System.out.println("|----------------------|-----");
				System.out.println("|                    __|__   ");
				System.out.println("|                    |x x|   ");
				System.out.println("|                    | ' |   ");
				System.out.println("|                    |_=_|   ");
				System.out.println("|                    /| |\\   ");
				System.out.println("|                   / | | \\  ");
				System.out.println("|                  /  | |  \\ ");
				System.out.println("|                     | |      ");
				System.out.println("|                    /   \\    ");
				System.out.println("|                   /     \\   ");
				System.out.println("|                  /       \\  ");
				System.out.println("|                            ");
				break;

		}
	}
	
}
