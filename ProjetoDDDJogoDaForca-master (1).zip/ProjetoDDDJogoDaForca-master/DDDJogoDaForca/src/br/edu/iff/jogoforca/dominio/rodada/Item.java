package br.edu.iff.jogoforca.dominio.rodada;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import br.edu.iff.bancodepalavras.dominio.letra.Letra;
import br.edu.iff.bancodepalavras.dominio.palavra.Palavra;
import br.edu.iff.dominio.ObjetoDominioImpl;

public class Item extends ObjetoDominioImpl{

	private boolean[] posicoesDescobertas;
	private String palavraArriscada = null;
	private Palavra palavra;
	
	 static Item criar( int id, Palavra palavra) {
		return new Item(id, palavra);
		
	}
	
	public static Item reconstituir( int id, Palavra palavra, int[] posicoesDescobertas ,String palavraArriscada) {
		return new Item(id, palavra, posicoesDescobertas, palavraArriscada);
	}
	
	private  Item(int id, Palavra palavra) {
		super(id);
		this.palavra = palavra;
		this.posicoesDescobertas = new boolean[palavra.getTamanho()];
	}
	
	private  Item(int id, Palavra palavra, int[] posicoesDescobertas ,String palavraArriscada) {
		super(id);
		this.palavra = palavra;
		this.palavraArriscada = palavraArriscada;
		this.posicoesDescobertas = new boolean[posicoesDescobertas.length];
		int pos = 0;
		while (pos < posicoesDescobertas.length) {
			this.posicoesDescobertas[posicoesDescobertas[pos]] = true;
			pos++;
		}
	}
	
	public Palavra getPalavra() {
		return this.getPalavra();
	}

	public Set<Letra>  getLetrasDescobertas() {
        Set<Letra> descobertas = new HashSet<>();
        for (int i = 0; i < posicoesDescobertas.length; i++) {
            if (posicoesDescobertas[i]) {
            	descobertas.add(palavra.getLetra(i));
            }
        }

        return descobertas;
	}
	
	public Set<Letra> getLetrasEncobertas() {
		Set<Letra> palavrasEncobertas = new HashSet<>();
        
        for (int i = 0; i < posicoesDescobertas.length; i++) {
            if (posicoesDescobertas[i] == false) {
                palavrasEncobertas.add(palavra.getLetra(i));
            }
        }

        return palavrasEncobertas;
	}
	
	public int qtdeLetrasEncobertas() {
		return getLetrasEncobertas().size();
	}
	
	public int calcularPontosLetrasEncobertas(int valorPorLetraEncoberta ) {	
		return valorPorLetraEncoberta * qtdeLetrasEncobertas();
		
	}
	
	public boolean descobriu() {
		return acertou() || qtdeLetrasEncobertas() == 0;	
	}
	
	public void exibir(Object contexto ) {
		palavra.exibir(contexto, posicoesDescobertas);
	}
	
	boolean tentar(char codigo) {
        List<Integer> posicoes = palavra.tentar(codigo);
        
        if (posicoes.size() == 0) {
                return false;
        }
 
        for (Integer p: posicoes) {
                posicoesDescobertas[p] = true;
        }

        return true;	
	}

	void arriscar(String palavra){
		palavraArriscada = palavra;
	}
	
	public String getPalavraArriscada() {
		return palavraArriscada;
	}

	public boolean  arriscou() {
		if(palavraArriscada != null) {
			return true;
		}
		return false;	
	}
	
	public boolean acertou() {
		if(this.palavraArriscada != null && palavra.comparar(palavraArriscada)) {
			return true;
		}
		return false;
	}
	
}
