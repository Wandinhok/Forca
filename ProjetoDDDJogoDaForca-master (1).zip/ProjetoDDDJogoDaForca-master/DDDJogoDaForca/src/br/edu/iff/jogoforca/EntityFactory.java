package br.edu.iff.jogoforca;

import br.edu.iff.repository.Repository;

public abstract class EntityFactory {
	protected Repository repository;
	protected EntityFactory(Repository repository) {
		this.repository = repository;
	}
	
	protected Repository getRepository() {
		return repository;
	}
	
	protected long getProximoId(){
		return repository.getProximoId();
	}
}
