package br.edu.iff.jogoforca.dominio.boneco.texto;

import br.edu.iff.jogoforca.dominio.boneco.Boneco;


public class BonecoTextoFactory{
	private static BonecoTextoFactory soleInstance = null;
	
	private BonecoTextoFactory() {
		
	}
	
	public static BonecoTextoFactory getSoleInstance() {
		//thread safety
		if (soleInstance == null) {
			synchronized(BonecoTextoFactory.class){
				if (soleInstance == null) {//verifica novamente para tratar a concorr�ncia
					soleInstance = new BonecoTextoFactory();
				}	
			}
		}
		return soleInstance;
	}


	public Boneco getBoneco() {
		return BonecoTexto.getSoleInstance();
	}

}

