package br.edu.iff.jogoforca.dominio.boneco.imagem;

import br.edu.iff.jogoforca.dominio.boneco.Boneco;

public class BonecoImagemFactory {
	private static BonecoImagemFactory soleInstance = null;
	
	private BonecoImagemFactory() {
		
	}
	
	public static BonecoImagemFactory getSoleInstance() {
		//thread safety
		if (soleInstance == null) {
			synchronized(BonecoImagemFactory.class){
				if (soleInstance == null) {//verifica novamente para tratar a concorr�ncia
					soleInstance = new BonecoImagemFactory();
				}	
			}
		}
		return soleInstance;
	}


	public Boneco getBoneco() {
		return BonecoImagem.getSoleInstance();
	}
}