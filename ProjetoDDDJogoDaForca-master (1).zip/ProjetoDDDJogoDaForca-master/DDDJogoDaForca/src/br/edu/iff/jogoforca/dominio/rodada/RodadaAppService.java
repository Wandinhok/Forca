package br.edu.iff.jogoforca.dominio.rodada;

import br.edu.iff.jogoforca.dominio.jogador.Jogador;
import br.edu.iff.jogoforca.dominio.jogador.JogadorNaoEncontradoException;
import br.edu.iff.jogoforca.dominio.jogador.JogadorRepository;

public class RodadaAppService {
	private static RodadaAppService soleInstance= null;
	private RodadaRepository rodadaRepository;
	private JogadorRepository jogadorRepository;
	private RodadaFactory rodadaFactory;

	private RodadaAppService(RodadaRepository rodadaRepository, JogadorRepository jogadorRepository) {
		super();
		this.rodadaRepository = rodadaRepository;
		this.jogadorRepository = jogadorRepository;
	}

	public static void createSoleInstance(RodadaRepository rodadaRepository, JogadorRepository jogadorRepository) {
		soleInstance = new RodadaAppService(rodadaRepository, jogadorRepository);
	}	

	public static RodadaAppService getSoleInstance() {
		return soleInstance;
	}
	
	public Rodada novaRodada (long idJogador) throws JogadorNaoEncontradoException {
		try{
			Jogador jogador = jogadorRepository.getPorId(idJogador);
			return rodadaFactory.getRodada(jogador);
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
		throw new JogadorNaoEncontradoException("N�o foi poss�vel encontrar o jogador" );
	}
	
	public Rodada novaRodada (String nomeJogador) throws JogadorNaoEncontradoException {
		Jogador jogador = jogadorRepository.getPorNome(nomeJogador);
		if(jogador == null) {
			throw new JogadorNaoEncontradoException(nomeJogador);
		}
		return rodadaFactory.getRodada(jogador);
	}
	
	
	public Rodada novaRodada (Jogador jogador) {
		return rodadaFactory.getRodada(jogador);
	}  
	
	public boolean salvarRodada(Rodada rodada) {
		try {
			rodadaRepository.inserir(rodada);
			return true;
		}
		catch(Exception e) {
			System.out.println("N�o foi poss�vel salvar rodada");
		}
		return false;
	}
}
