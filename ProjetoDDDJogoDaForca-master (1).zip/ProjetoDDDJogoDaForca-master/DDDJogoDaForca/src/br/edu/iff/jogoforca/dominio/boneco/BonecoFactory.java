package br.edu.iff.jogoforca.dominio.boneco;

public interface BonecoFactory{
	Boneco getBoneco();
}
