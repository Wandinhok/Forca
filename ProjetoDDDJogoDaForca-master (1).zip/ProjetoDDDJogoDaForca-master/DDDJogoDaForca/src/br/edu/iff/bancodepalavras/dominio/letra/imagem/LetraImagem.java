package br.edu.iff.bancodepalavras.dominio.letra.imagem;

import br.edu.iff.bancodepalavras.dominio.letra.Letra;

public class LetraImagem extends Letra{

	protected LetraImagem(char codigo) {
		super(codigo);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Letra getLetra(char codigo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Letra getLetraEncoberta() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void exibir(Object contexto) {
		// TODO Auto-generated method stub
		
	}



}
