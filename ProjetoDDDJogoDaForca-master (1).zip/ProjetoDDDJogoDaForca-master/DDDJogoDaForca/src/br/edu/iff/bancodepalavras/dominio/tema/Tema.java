package br.edu.iff.bancodepalavras.dominio.tema;

import java.util.ArrayList;
import java.util.List;

import br.edu.iff.bancodepalavras.dominio.palavra.Palavra;
import br.edu.iff.dominio.ObjetoDominioImpl;

public class Tema extends ObjetoDominioImpl {
	
	private String nome;
	private List<Palavra> palavras;
	
	private Tema(long id, String nome) {
		super(id);
		this.nome = nome;
		this.palavras = new ArrayList<Palavra>();
	}
	
	public static Tema criar(long id, String nome) {
		return new Tema(id, nome);	
	}
	
	public static Tema reconstituir( long id, String nome) {
		return new Tema(id, nome);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
}
