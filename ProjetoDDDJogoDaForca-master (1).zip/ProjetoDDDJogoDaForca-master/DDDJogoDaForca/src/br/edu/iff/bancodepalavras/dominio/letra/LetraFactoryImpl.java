package br.edu.iff.bancodepalavras.dominio.letra;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class LetraFactoryImpl implements LetraFactory{
	private Letra encoberta = null;
	private Map<Character, Letra> pool = new ConcurrentHashMap<Character, Letra>(26);
	
	protected LetraFactoryImpl() {
		
	}
	
	public  abstract Letra getLetra(char codigo); // o final nao foi aqui, nao sei
	
	public final Letra getLetraEncoberta() {
		if(encoberta == null) {
			char simbolo = '#';
			this.encoberta = criarLetra(simbolo);
		}
		return this.encoberta;
	}
	
	protected abstract Letra criarLetra (char codigo);

	public Map<Character, Letra> getPool() {
		return pool;
	}

}
