package br.edu.iff.bancodepalavras.dominio.tema;

public interface TemaFactory {
	Tema getTema(String nome);
}
