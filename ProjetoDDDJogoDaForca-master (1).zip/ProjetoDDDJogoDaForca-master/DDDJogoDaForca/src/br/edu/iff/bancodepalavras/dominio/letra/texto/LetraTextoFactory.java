package br.edu.iff.bancodepalavras.dominio.letra.texto;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.edu.iff.bancodepalavras.dominio.letra.Letra;
import br.edu.iff.bancodepalavras.dominio.letra.LetraFactoryImpl;

public class LetraTextoFactory extends LetraFactoryImpl{
	private static final String REGEX = "[a-zA-Z]";
	private static LetraTextoFactory soleInstance = null;
	
	private LetraTextoFactory() {
		
	}
	
	public static LetraTextoFactory getSoleInstance() {
		//thread safety
		if (soleInstance == null) {
			synchronized(LetraTextoFactory.class){
				if (soleInstance == null) {//verifica novamente para tratar a concorr�ncia
					soleInstance = new LetraTextoFactory();
				}	
			}
		}
		return soleInstance;
	}

	
	protected Letra criarLetra(char codigo){
		getPool().put(codigo, new LetraTexto(codigo));
		return getPool().get(codigo);
	}
	
	public Letra getLetra(char codigo) {
		//esse tipo de verifica��o tem chances de mudar, vai depender dos testes
		
		Pattern re = Pattern.compile(REGEX);
		Matcher match = re.matcher(String.valueOf(codigo));
		if(!match.matches()) {
			throw new IllegalArgumentException("N�o � permitidos o uso de caracteres especiais, apenas letras!");
		}
		
		//verifica se existe no pool
		if(getPool().keySet().contains(codigo)) {
			return getPool().get(codigo);
		}
		//se n�o existir chama a fun��o pra criar a letra
		return criarLetra(codigo);
	}

}
