package br.edu.iff.bancodepalavras.dominio.palavra;

import java.util.List;

import br.edu.iff.bancodepalavras.dominio.tema.Tema;
import br.edu.iff.jogoforca.EntityFactory;

public class PalavraFactoryImpl extends EntityFactory implements PalavraFactory{
	private static PalavraFactoryImpl soleInstance= null;
	private PalavraRepository repository;
	private PalavraFactoryImpl(PalavraRepository repository) {
		super(repository);
		this.repository = repository;
	}
	
	public static void createSoleInstance(PalavraRepository repository) {
		soleInstance = new PalavraFactoryImpl(repository);
	}
	
	public static PalavraFactoryImpl getSoleInstance() {
		return soleInstance;
	}
	
	private PalavraRepository getPalavraRepository() {
		return repository;
	}
	
	public Palavra getPalavra(String palavra, Tema tema) {
		List<Palavra> palavras = getPalavraRepository().getPorTema(tema);
		for(Palavra obj : palavras) {
			if(obj.comparar(palavra.toLowerCase())) {
				return obj;
			}
		}
		return Palavra.criar(repository.getProximoId(), palavra.toLowerCase(), tema);
	}
}
