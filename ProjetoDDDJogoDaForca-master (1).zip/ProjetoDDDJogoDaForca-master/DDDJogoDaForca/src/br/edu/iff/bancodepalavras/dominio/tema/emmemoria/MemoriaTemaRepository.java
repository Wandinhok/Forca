package br.edu.iff.bancodepalavras.dominio.tema.emmemoria;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import br.edu.iff.bancodepalavras.dominio.tema.Tema;
import br.edu.iff.bancodepalavras.dominio.tema.TemaRepository;
import br.edu.iff.repository.RepositoryException;

public class MemoriaTemaRepository implements TemaRepository{

private static MemoriaTemaRepository soleInstance = null;
	
	
	public static synchronized MemoriaTemaRepository getSoleInstance() {
		if (soleInstance == null) 
			soleInstance = new MemoriaTemaRepository();
		return soleInstance;
	}
	
	  private List<Tema> pool;

	  private MemoriaTemaRepository() {
	    pool = new ArrayList<>();
	  }

	  @Override
	  public long getProximoId() {
	    return pool.size() + 1;
	  }

	  @Override
	  public Tema getPorId(long id) {    

	    for (Tema tema: pool) {
	      if (tema.getId() == id) {
	        return tema;
	      } 
	    }  
	    return null;
	  }

	  @Override
	  public Tema getPorNome(String nome) {
	    for (Tema tema: pool) {
	      if(tema.getNome().equalsIgnoreCase(nome)) {
	    	  return tema;
	      }
	    }
	    return null;
	  }

	  @Override
	  public List<Tema> getTodos() {
	    return Collections.unmodifiableList(pool);
	  }

	  @Override
	  public void inserir(Tema tema) throws RepositoryException {
	    
	    if (pool.contains(tema)) {
	      throw new RepositoryException("O tema " + tema + " J� est�o salvos no reposit�rio.");
	    } else {
	      pool.add(tema);
	    }

	  }

	  @Override
	  public void atualizar(Tema tema) throws RepositoryException {
	    this.remover(tema);
	    this.inserir(tema);
	  }

	  @Override
	  public void remover(Tema tema) throws RepositoryException {
	    if (pool.contains(tema)) {
	        pool.remove(tema);
	    } else {
	        throw new RepositoryException("O tema " + tema + "N�o est�o salvos no reposit�rio.");
	    }
	  }

	

	  
}
