package br.edu.iff.bancodepalavras.dominio.palavra;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import br.edu.iff.bancodepalavras.dominio.letra.Letra;
import br.edu.iff.bancodepalavras.dominio.letra.LetraFactory;
import br.edu.iff.bancodepalavras.dominio.tema.Tema;
import br.edu.iff.dominio.ObjetoDominioImpl;
import br.edu.iff.jogoforca.dominio.rodada.Item;

public class Palavra extends ObjetoDominioImpl{
	
	private Letra[] caracteresPalavra;
	private Letra[] encoberta;
	private static LetraFactory letraFactory;
	private Tema tema;
	//private List<Item> itens;
	
	private Palavra(long id, String palavra, Tema tema) {
		super(id);
		int pos = 0;
		caracteresPalavra = new Letra[palavra.length()];
		encoberta = new Letra[palavra.length()];
		for(Letra letra : caracteresPalavra) {
			caracteresPalavra[pos] = letraFactory.getLetra(palavra.charAt(pos));
			pos++;
		}
		pos = 0;
		for(Letra letra : encoberta) {
			encoberta[pos] = letraFactory.getLetraEncoberta();
			pos++;
		}
		this.tema = tema;
	}
	
	public static void setLetraFactory(LetraFactory factory) {
		letraFactory = factory;
	}
	
	public static LetraFactory getLetraFactory() {
		return letraFactory;
		
	}
	
	public static Palavra criar(long id, String palavra, Tema tema) {
		if(letraFactory == null) {
			return null;
		}
		return new Palavra(id, palavra, tema);
	}
	
	public static Palavra reconstituir(long id, String palavra, Tema tema) {
		return null; // fazer l�gica
	}
	
	public Letra[] getLetras(){	
		return caracteresPalavra;// fazer l�gica	
	}

	public Letra getLetra(int posicao) {
		int pos = 0;
		for(Letra letra : caracteresPalavra) {
			if(posicao == pos) {
				return letra;
			}
			pos++;
		}
		return null;// fazer l�gica
	}
	
	public void exibir(Object contexto) {
		
	}
	
	public void exibir(Object contexto, boolean[] posicoes) {
		int pos = 0;
		StringBuilder stringBuilder = new StringBuilder();
		while(pos < posicoes.length) {
			if(posicoes[pos]){
				stringBuilder.append(caracteresPalavra[pos].getCodigo()).append(" ");
			}
			else{
				stringBuilder.append(letraFactory.getLetraEncoberta().getCodigo()).append(" ");
			};
			pos++;
		}
		System.out.println(stringBuilder.toString());
	}
	
	public List<Integer> tentar(char codigo) {

		List<Integer> posicoesDaLetra = new ArrayList<>();
		int pos = 0;
		for (Letra letra : caracteresPalavra) {
			if(letra.getCodigo() == codigo) {
				posicoesDaLetra.add(pos);

			}
			pos++;
		}

		return posicoesDaLetra; 
	}
	
	public Tema getTema() {
		return tema;	
	}
	
	public boolean comparar(String palavra) {
		int pos = 0;
		for(Letra letra : caracteresPalavra) {
			if(palavra.charAt(pos) != letra.getCodigo()) {
				return false;
			}
			pos++;
		}
		return true;
		
	}
	
	public int getTamanho() {
		return caracteresPalavra.length; // fazer l�gica
	}

	@Override
	public String toString() {
		return "Palavra [caracteresPalavra=" + Arrays.toString(caracteresPalavra) + ", encoberta="
				+ Arrays.toString(encoberta) + ", tema=" + tema;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Palavra)) return false;
		Palavra palavra = (Palavra) o;
		return Arrays.equals(caracteresPalavra, palavra.caracteresPalavra) && Arrays.equals(encoberta, palavra.encoberta) && Objects.equals(getTema(), palavra.getTema());
	}

	@Override
	public int hashCode() {
		int result = Objects.hash(getTema());
		result = 31 * result + Arrays.hashCode(caracteresPalavra);
		result = 31 * result + Arrays.hashCode(encoberta);
		return result;
	}
}
