package br.edu.iff.bancodepalavras.dominio.tema;

import br.edu.iff.jogoforca.EntityFactory;
import br.edu.iff.repository.Repository;

public class TemaFactoryImpl extends EntityFactory implements TemaFactory{
	private static TemaFactoryImpl soleInstance= null;
	private TemaRepository repository;
	private TemaFactoryImpl(TemaRepository repository) {
		super(repository);
		this.repository = repository;
	}
	
	public static void createSoleInstance(TemaRepository repository) {
		soleInstance = new TemaFactoryImpl(repository);
	}
	
	public static TemaFactoryImpl getSoleInstance() {
		return soleInstance;
	}
	
	private TemaRepository getTemaRepository() {
		return repository;
	}
	
	public Tema getTema(String nome) {
		if(getTemaRepository().getPorNome(nome) == null) {
			return Tema.criar(repository.getProximoId(), nome);
		}
		return getTemaRepository().getPorNome(nome);
	}

}
