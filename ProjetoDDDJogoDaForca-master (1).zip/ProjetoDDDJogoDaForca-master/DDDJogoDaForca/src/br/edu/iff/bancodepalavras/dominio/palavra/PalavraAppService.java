package br.edu.iff.bancodepalavras.dominio.palavra;

import br.edu.iff.bancodepalavras.dominio.tema.Tema;
import br.edu.iff.bancodepalavras.dominio.tema.TemaRepository;


public class PalavraAppService {
	private static PalavraAppService soleInstance= null;
	private TemaRepository temaRepository;
	private PalavraRepository palavraRepository;
	private PalavraFactory palavraFactory;

	private PalavraAppService(TemaRepository temaRepository, PalavraRepository palavraRepository) {
		super();
		this.temaRepository = temaRepository;
		this.palavraRepository = palavraRepository;
	}

	public static void createSoleInstance(TemaRepository temaRepository, PalavraRepository palavraRepository) {
		soleInstance = new PalavraAppService(temaRepository, palavraRepository);
	}	

	public static PalavraAppService getSoleInstance() {
		return soleInstance;
	}
	
	public boolean novaPalavra(String palavra, long idTema) {
		Tema tema = temaRepository.getPorId(idTema);
		if( tema == null) {
			return false;
		}
		if(palavraFactory.getPalavra(palavra, tema) != null) {
			return true;
		}
		
		try {
			palavraRepository.inserir(Palavra.criar(palavraRepository.getProximoId() ,palavra, tema));	
			return true;
		}
		catch(Exception e) {
			System.out.println("N�o foi poss�vel inserir nova palavra!");
		}
		return false;
	}
	

}
