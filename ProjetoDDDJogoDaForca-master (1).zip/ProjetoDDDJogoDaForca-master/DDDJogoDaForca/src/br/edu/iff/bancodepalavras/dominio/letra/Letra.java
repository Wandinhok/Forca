package br.edu.iff.bancodepalavras.dominio.letra;

import java.util.ArrayList;
import java.util.Objects;

import br.edu.iff.bancodepalavras.dominio.palavra.Palavra;

public abstract class Letra implements LetraFactory{
	private char codigo;
	//private ArrayList<Palavra> palavras;
	
	protected Letra (char codigo) {
		this.codigo = codigo;
	}
	
	public char getCodigo(){
		return this.codigo;
	}
	
	public abstract void exibir(Object contexto);

	@Override
	public int hashCode() {
		return this.codigo+this.getClass().hashCode();

	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof Letra)) 
			return false;
		Letra outra = (Letra) o;
		return this.codigo == outra.codigo && this.getClass().equals(outra.getClass());
	}

	@Override
	public String toString() {
		return "Letra [codigo=" + codigo + "]";
	}
	
	
	
}
