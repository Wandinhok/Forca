package br.edu.iff.bancodepalavras.dominio.letra.imagem;

import br.edu.iff.bancodepalavras.dominio.letra.Letra;
import br.edu.iff.bancodepalavras.dominio.letra.LetraFactoryImpl;

public class LetraImagemFactory extends LetraFactoryImpl {
	private static LetraImagemFactory soleInstance = null;
	
	private LetraImagemFactory() {
		
	}
	
	public static LetraImagemFactory getSoleInstance() {
		//thread safety
		if (soleInstance == null) {
			synchronized(LetraImagemFactory.class){
				if (soleInstance == null) {//verifica novamente para tratar a concorr�ncia
					soleInstance = new LetraImagemFactory();
				}	
			}
		}
		return soleInstance;
	}


	protected Letra criarLetra(char codigo) {
		return new LetraImagem(codigo);
	}

	@Override
	public Letra getLetra(char codigo) {
		return null;
	}
}
