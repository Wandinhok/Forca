package br.edu.iff.dominio;

public interface ObjetoDominio {
	
	public long getId();
	
}
