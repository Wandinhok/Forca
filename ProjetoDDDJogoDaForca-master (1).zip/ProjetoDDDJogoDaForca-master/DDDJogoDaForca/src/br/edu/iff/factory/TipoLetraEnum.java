package br.edu.iff.factory;

public enum TipoLetraEnum {
	TEXTO, IMAGEM;
}
