import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

import br.edu.iff.bancodepalavras.dominio.letra.Letra;
import br.edu.iff.bancodepalavras.dominio.palavra.PalavraFactory;
import br.edu.iff.bancodepalavras.dominio.tema.Tema;
import br.edu.iff.bancodepalavras.dominio.tema.TemaFactory;
import br.edu.iff.jogoforca.Aplicacao;
import br.edu.iff.jogoforca.dominio.jogador.Jogador;
import br.edu.iff.jogoforca.dominio.jogador.JogadorFactory;
import br.edu.iff.jogoforca.dominio.rodada.Rodada;
import br.edu.iff.jogoforca.dominio.rodada.RodadaFactory;
import br.edu.iff.repository.RepositoryException;

public class MainTeste {

    private List<String> buffer = new ArrayList<String>();
    
    public void adicionar(String s) {
        this.buffer.add(s);
    };

    public static void main(String[] args) throws Exception {
           
        System.out.println("Bem vindo ao Jogo da Forca!!");
           
        Scanner scan = new Scanner(System.in);
        Aplicacao aplicacao = Aplicacao.getSoleInstance();
        aplicacao.configurar();
        JogadorFactory jFactory = aplicacao.getJogadorFactory();
        RodadaFactory rFactory = aplicacao.getRodadaFactory();
        TemaFactory tfactory = aplicacao.getTemaFactory();
        setTema(tfactory, aplicacao);
        iniciarJogo(jFactory, rFactory, aplicacao);
   
    }
   
    private static Jogador iniciarJogador(JogadorFactory jogador, Aplicacao aplicacao, String nome) {
    	Jogador player = jogador.getJogador(nome);
    	try {
			aplicacao.getRepositoryFactory().getJogadorRepository().inserir(player);
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return player;
    }
    
    private static void iniciarJogo(JogadorFactory jFactory, RodadaFactory rFactory, Aplicacao aplicacao) {     
        Rodada rodada = rFactory.getRodada(iniciarJogador(jFactory, aplicacao,"Jogador 1"));
        System.out.println("---------------------------");
        System.out.print("O tema é '" + rodada.getTema().getNome() +"'");
        iniciaJogoForca(rodada);
    }
   
    private static void iniciaJogoForca(Rodada r) {
        Scanner scan = new Scanner(System.in);
        while (r.encerrou() == false) {
            System.out.print("Tentativas: ");
            StringBuilder stringBuilder = new StringBuilder();
            for (Letra tentativa: r.getTentativas()) {
//                tentativa.exibir(null);
                stringBuilder.append(tentativa.getCodigo()).append("-");
            }
            System.out.println(stringBuilder.toString());
            System.out.println("Palavras:");
            r.exibirItens(null);
            System.out.println();
            System.out.println("Erros: " + r.getQtdeErros() + "/" + Rodada.getMaxErros());
            System.out.println();
            r.exibirBoneco(null);
            System.out.print("Digite uma letra: ");
            Character codigo = scan.next().charAt(0);

            r.tentar(codigo.toString().toLowerCase().charAt(0));
            System.out.println("");

        }

        if (r.descobriu()) {
            System.out.println("Parabéns, você ganhou o jogo!");
        }
        else {
            System.out.println("Erros: " + r.getQtdeErros() + "/" + Rodada.getMaxErros());
            r.exibirBoneco(null);
            System.out.println("Você perdeu!");

        }

        System.out.println("Pontos: " + r.calcularPontos());

        scan.close();
    }
   
    private static void setTema(TemaFactory tfactory, Aplicacao aplicacao) {
        Tema tFilmes = tfactory.getTema("Filmes");
        Tema tCarros = tfactory.getTema("Carros");
        PalavraFactory palavra = aplicacao.getPalavraFactory();
        PalavraFactory palavra2 = aplicacao.getPalavraFactory();
        try {
			aplicacao.getRepositoryFactory().getTemaRepository().inserir(tCarros);
			aplicacao.getRepositoryFactory().getTemaRepository().inserir(tFilmes);
			aplicacao.getRepositoryFactory().getPalavraRepository().inserir(palavra.getPalavra("Eternos", tFilmes));
			aplicacao.getRepositoryFactory().getPalavraRepository().inserir(palavra.getPalavra("Hulk", tFilmes));
			aplicacao.getRepositoryFactory().getPalavraRepository().inserir(palavra.getPalavra("Vingadores", tFilmes));
            aplicacao.getRepositoryFactory().getPalavraRepository().inserir(palavra.getPalavra("Ultimato", tFilmes));
            aplicacao.getRepositoryFactory().getPalavraRepository().inserir(palavra.getPalavra("Spiderman", tFilmes));
            aplicacao.getRepositoryFactory().getPalavraRepository().inserir(palavra.getPalavra("Ironman", tFilmes));
			aplicacao.getRepositoryFactory().getPalavraRepository().inserir(palavra2.getPalavra("Celta", tCarros));
			aplicacao.getRepositoryFactory().getPalavraRepository().inserir(palavra2.getPalavra("BMW", tCarros));
			aplicacao.getRepositoryFactory().getPalavraRepository().inserir(palavra2.getPalavra("Camaro", tCarros));
            aplicacao.getRepositoryFactory().getPalavraRepository().inserir(palavra2.getPalavra("Pampa", tCarros));
            aplicacao.getRepositoryFactory().getPalavraRepository().inserir(palavra2.getPalavra("Audi", tCarros));
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }
}
